<!DOCTYPE html>
<html lang="en">
<head>
	<title>TimeSheet</title>
    <?php require_once 'head.php'; ?>
</head>
<body>

	<?php require_once 'header.php'; ?>
    
    <div class="container">

	<h1>TimeSheet / Register</h1>

	<form action="backend/registerController.php" method="POST">

		<div class="form-group">
			<label for="name">Name:</label>
			<input type="text" name="name" >
		</div>

		<div class="form-group">
			<label for="email">Email:</label>
			<input type="email" name="email" >
		</div>

		<div class="form-group">
			<label for="password">Password:</label>
			<input type="password" name="password" >
		</div>

		<div class="form-group">
			<label for="password">Password Confirm:</label>
			<input type="password" name="password_check" >
		</div>
		
		<input type="submit" value="Register" >
	</form>
</div>
</body>
</html>