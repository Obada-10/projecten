<?php 

$email = $_POST['email'];
if(filter_var($email,FILTER_VALIDATE_EMAIL)===false)
	{
		$errors[] = "Email is ongeldig!";
	}
$name = $_POST['name'];

$password = $_POST['password'];
if (empty($password)) {
	$errors[] = "Wachtwoord is leeg";
}

$password_check = $_POST['password_check'];

if($password !== $password_check) {
	$errors[] = "Wachtwoorden komen niet overeen...";
}

if(isset($errors)){
            var_dump($errors);
            die;
        }

$password = password_hash($password, PASSWORD_DEFAULT);

require_once 'conn.php';

$query = "INSERT INTO users (username, name, password)
	VALUES (:email, :name, :password)";

$statement = $conn->prepare($query);

$statement->execute([
	":email" => $email,
	":name" => $name,
	":password" => $password
]);


$msg = "Succesvol gergisteerd";
header("Location: ../login.php?msg=$msg");

exit;
?>