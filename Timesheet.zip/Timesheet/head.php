<?php require_once 'backend/config.php'; ?>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo $base_url; ?>/css/normalize.css">
<link rel="stylesheet" href="<?php echo $base_url; ?>/css/main.css">
<link rel="icon" href="<?php echo $base_url; ?>/favicon.ico" type="image/x-icon" />
