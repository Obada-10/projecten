<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <title>index</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #f9f9f9;
            font-weight: bold;
        }

        .telefoon-link {
            color: #333;
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .telefoon-link:hover {
          
            color: #777;
        }

        .kleurvierkant {
         width: 20px;
         height: 20px;
}
.message {
    background-color: greenyellow;
    padding: 10px;
    border: 1px solid black;
    margin-bottom: 10px;
}

        
    </style>
</head>
<body>

    <a href="/create" class="btn btn-primary mt-2">Create schoen</a>
    <a href="/aangepaste" class="btn btn-primary mt-2"> Schoenen met specifieke voorwaarden</a>

    <h1>View pagina</h1>

    @if (session()->has('message'))
    <div>
        {{ session()->get('message')}}
    </div>
@endif


    <table>
        <thead>
            <tr>
                <th>Merk</th>
                <th>Kleur</th>
                <th>Maat</th>
                <th>Prijs</th>
                <th>Winkel Name</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($schoenen as $schoen)
                <tr>
                    <td><a href="/schoenen/{{$schoen->id}}" class="telefoon-link">{{$schoen->merk}}</a></td>
                    <td>{{$schoen->kleur}}<div class="kleurvierkant" style="background-color: {{$schoen->kleur}};"></div></td>
                    <td>{{$schoen->maat}}</td>
                    <td>{{$schoen->prijs}}</td>
                    <td>{{$schoen->categorie_name}}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    
    
</body>
</html> 
