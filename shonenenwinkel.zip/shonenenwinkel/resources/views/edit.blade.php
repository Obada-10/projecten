<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>


    <h1>Edit Pagina</h1>
    <form action="/schoenen/{{$schoen->id}}" method="POST">
        @csrf
        @method('PUT')
        <label for="name">Merk:</label><br>
        <input value="{{$schoen->merk}}" type="text" id="merk" name="merk" required><br>
       
        <label for="kleur">Kluer:</label><br>
        <input value="{{$schoen->kleur}}" type="color" id="kleur" name="kleur" required><br>

        <label for="maat">Maat:</label><br>
        <input value="{{$schoen->maat}}" type="number" id="maat" name="maat" required><br>

        <label for="prijs">Prijs:</label><br>
        <input value="{{$schoen->prijs}}" type="number" id="prijs" name="prijs" required><br>

        <label for="categorie">categorie:</label><br>
        <select name="categorie" id="categorie">
            <option value="">Selecteer een winkel</option>

            @foreach($categorieen as $categorie)
            <option @if($schoen->categorie_id == $categorie->id) selected @endif value="{{$categorie->id}}">{{$categorie->name}}</option>
            @endforeach
        </select><br>

        <input type="submit" value="Verzenden">
    </form>
</body>
</html>
