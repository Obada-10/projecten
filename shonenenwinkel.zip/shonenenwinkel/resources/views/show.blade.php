<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        .details {
            background-color: #fff;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .details p {
            margin: 0;
            margin-bottom: 10px;
        }

        .edit-link {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        .edit-link:hover {
            background-color: #555;
        }

        .delete-form {
            display: inline-block;
            margin-left: 10px;
        }

        .delete-button {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .delete-button:hover {
            background-color: #555;
        }

        .kleurvierkant {
  width: 20px;
  height: 20px;
}
    </style>
</head>
<body>

    <a href="/index" class="btn btn-primary mt-2">Home</a>

    <h1>Detail pagina</h1>

    <div class="details">
        <p>
            Merk: {{$schoen->merk}} <br>
            Kleur: {{$schoen->kleur}} <div class="kleurvierkant" style="background-color: {{$schoen->kleur}};"></div><br>
            Maat: {{$schoen->maat}} <br>
            Prijs: {{$schoen->prijs}} <br>
            Winkel: {{$schoen->categorie_name}} <br>
        </p>
    </div>

    <a href="/schoenen/{{$schoen->id}}/edit" class="edit-link">Bewerk Schoen</a>

    <form action="/schoenen/{{$schoen->id}}" method="POST" class="delete-form">
        @csrf
        @method("DELETE")
        <button type="submit" class="delete-button">Delete</button>
    </form>
</body>
</html>
