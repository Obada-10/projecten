<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <h1>Voeg nieuw schoen</h1>
    <form action="/schoenen" method="POST">
        @csrf
        <label for="merk">Merk:</label>
        <input type="text" id="merk" name="merk" required>

        <label for="kleur">Kleur:</label>
        <input type="color" id="kleur" name="kleur" required>

        <label for="maat">Maat:</label>
        <input type="number" id="maat" name="maat" required>

        <label for="prijs">Prijs:</label>
        <input type="number" id="prijs" name="prijs" required>
        

        <label for="categorie">categorie:</label>
        <select name="categorie" id="categorie">
            <option value="">Selecteer een winkel</option>
            @foreach($categorieen as $categorie)
                <option value="{{$categorie->id}}">{{$categorie->name}}</option>
            @endforeach
        </select>

        <input type="submit" value="Verzenden">
    </form>
</body>
</html>
