<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <title>index</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #f9f9f9;
            font-weight: bold;
        }

        .telefoon-link {
            color: #333;
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .telefoon-link:hover {
          
            color: #777;
        }

        .kleurvierkant {
         width: 20px;
         height: 20px;
}
.message {
    background-color: greenyellow;
    padding: 10px;
    border: 1px solid black;
    margin-bottom: 10px;
}

        
    </style>
</head>
<body>

    <a href="/create" class="btn btn-primary mt-2">Create schoen</a>
    <a href="/aangepaste" class="btn btn-primary mt-2"> Schoenen met specifieke voorwaarden</a>

    <h1>View pagina</h1>

    <?php if(session()->has('message')): ?>
    <div>
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>


    <table>
        <thead>
            <tr>
                <th>Merk</th>
                <th>Kleur</th>
                <th>Maat</th>
                <th>Prijs</th>
                <th>Winkel Name</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $schoenen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schoen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="/schoenen/<?php echo e($schoen->id); ?>" class="telefoon-link"><?php echo e($schoen->merk); ?></a></td>
                    <td><?php echo e($schoen->kleur); ?><div class="kleurvierkant" style="background-color: <?php echo e($schoen->kleur); ?>;"></div></td>
                    <td><?php echo e($schoen->maat); ?></td>
                    <td><?php echo e($schoen->prijs); ?></td>
                    <td><?php echo e($schoen->categorie_name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    
</body>
</html> 
<?php /**PATH C:\xampp8.2\htdocs\shonenenwinkel\resources\views/index.blade.php ENDPATH**/ ?>