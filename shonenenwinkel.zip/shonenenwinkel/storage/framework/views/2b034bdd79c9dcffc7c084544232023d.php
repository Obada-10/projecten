<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <h1>Edit Pagina</h1>
    <form action="/schoenen/<?php echo e($schoen->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="name">Merk:</label><br>
        <input value="<?php echo e($schoen->merk); ?>" type="text" id="merk" name="merk" required><br>
       
        <label for="kleur">Kluer:</label><br>
        <input value="<?php echo e($schoen->kleur); ?>" type="color" id="kleur" name="kleur" required><br>

        <label for="maat">Maat:</label><br>
        <input value="<?php echo e($schoen->maat); ?>" type="number" id="maat" name="maat" required><br>

        <label for="prijs">Prijs:</label><br>
        <input value="<?php echo e($schoen->prijs); ?>" type="number" id="prijs" name="prijs" required><br>

        <label for="categorie">categorie:</label><br>
        <select name="categorie" id="categorie">
            <option value="">Selecteer een winkel</option>

            <?php $__currentLoopData = $categorieen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($schoen->categorie_id == $categorie->id): ?> selected <?php endif; ?> value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>

        <input type="submit" value="Verzenden">
    </form>
</body>
</html>
<?php /**PATH C:\xampp8.3\htdocs\shonenenwinkel\resources\views/edit.blade.php ENDPATH**/ ?>