<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class pagesController extends Controller
{
    public function index(){
        $schoen = DB::table('schoenen')
        ->join('categorieen', 'schoenen.categorie_id', '=', 'categorieen.id')
        ->select('schoenen.*', 'categorieen.name as categorie_name')
        ->get();    

        return view('index', [
                    'schoenen' => $schoen
        ]);
    }


    public function create(){
        $categorieen = DB::table('categorieen')->get();
        
        return view('create',[
            'categorieen' => $categorieen
        ]);
    }



    public function store(Request $request)
{
    $request->validate([
        'merk' => 'required',
        'kleur' => 'required',
        'maat' => 'required|numeric',
        'prijs' => 'required|numeric',
        'categorie' => 'required',
    ]);

    DB::table('schoenen')->insert([
        'merk' => $request->merk,
        'kleur' => $request->kleur,
        'maat' => $request->maat,
        'prijs' => $request->prijs,
        'categorie_id' => $request->categorie,
    ]);

    
    return redirect('/')->with('message', 'schoen is toegevoeg');
}


    public function show(string $id)
    {
        $schoen = DB::table('schoenen')
            ->join('categorieen', 'schoenen.categorie_id', '=', 'categorieen.id')
            ->select('schoenen.*', 'categorieen.name as categorie_name')
            ->where('schoenen.id', $id)
            ->first();

            $categorie = DB::table('categorieen')
            ->where('id', $id)
            ->first();
    
    
        return view('show', [
            'schoen' => $schoen,
            'categorie' => $categorie
        ]);
    }


    public function destroy(string $id){
        $schoen = DB::table('schoenen')->where('id', $id)->delete();
        return redirect('/');
    }


    public function edit(string $id){

        $schoen = DB::table('schoenen')
            ->where('id', $id)
            ->first();
            
        $categorieen = DB::table('categorieen')->get();

        return view('edit', [
            'schoen' => $schoen,
            'categorieen' => $categorieen

        ]);

    }


    public function update(Request $request, string $id){

        $request->validate([
            'merk' => 'required',
            'kleur' => 'required',
            'maat' => 'required|numeric',
            'prijs' => 'required|numeric',
            'categorie' => 'required',
        ]);
    

        $schoen = DB::table('schoenen')->where('id', $id)->update([
            'merk'=> $request->merk,
            'kleur'=> $request->kleur,
            'maat'=> $request->maat,
            'prijs'=> $request->prijs,
            'categorie_id'=> $request->categorie


        ]);

        return redirect('/');

    }

    public function aangepastepagina()
    {
        $schoen = DB::table('schoenen')
            ->join('categorieen', 'schoenen.categorie_id', '=', 'categorieen.id')
            ->select('schoenen.*', 'categorieen.name as categorie_name')
            ->where('schoenen.prijs', '>', 100)
            ->where('schoenen.maat', '>', 38)
            ->get();
    
        return view('aangepaste', [
            'schoenen' => $schoen
        ]);
    }
    



    
}
