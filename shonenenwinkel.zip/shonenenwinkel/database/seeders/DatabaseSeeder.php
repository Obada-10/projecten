<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        DB::table('categorieen')->insert([

            [
                'name' => 'Sportschonen',
                

            ],

            [
                'name' => 'Sneakers',
                

            ],

            [
                'name' => 'Laarzen',

            ]
            


        ]);


        DB::table('schoenen')->insert([


            [
                'merk'=> 'Nike',
                'kleur' => 'Zwart',
                'maat' => '42',
                'prijs' => 120,
                'categorie_id' => 1


            ],

            [
                'merk'=> 'Adidas',
                'kleur' => 'Wit',
                'maat' => '39',
                'prijs' => 90,
                'categorie_id' => 2



            ],

            [
                'merk'=> 'Puma',
                'kleur' => 'Rood',
                'maat' => '40',
                'prijs' => 80,
                'categorie_id' => 2


            ],
                

            [
                'merk'=> 'Nike',
                'kleur' => 'Blauw',
                'maat' => '41',
                'prijs' => 110,
                'categorie_id' => 1

            ],

            [
                'merk'=> 'Adidas',
                'kleur' => 'Greon',
                'maat' => '38',
                'prijs' => 95,
                'categorie_id' => 1

            ],

            [
                'merk'=> 'Timeberland',
                'kleur' => 'Bruin',
                'maat' => '44',
                'prijs' => 150,
                'categorie_id' => 3

            ],

            [
                'merk'=> 'Nike',
                'kleur' => 'Grijs',
                'maat' => '43',
                'prijs' => 130,
                'categorie_id' => 1

            ],

            [
                'merk'=> 'Adidas',
                'kleur' => 'Zwart',
                'maat' => '37',
                'prijs' => 100,
                'categorie_id' => 2

            ]



        ]);

    }
}
