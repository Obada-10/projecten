<?php

use App\Http\Controllers\pagesController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [pagesController::class, 'index']);
Route::get('/index', [pagesController::class, 'index']);
Route::get('create', [pagesController::class, 'create']);
Route::post('/schoenen', [pagesController::class, 'store']);
Route::get('/schoenen/{id}', [pagesController::class, 'show']);
Route:: delete('/schoenen/{id}', [pagesController::class, 'destroy']);
Route::get('/schoenen/{id}/edit/', [pagesController::class, 'edit']);
Route:: put('/schoenen/{id}', [pagesController::class, 'update']);
Route::get('aangepaste', [pagesController::class, 'aangepastepagina']);
